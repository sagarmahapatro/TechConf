package com.prospringhibernate.gallery.domain;


public enum RoleLevel {

    GUEST, REGISTERED, ADMIN
}
