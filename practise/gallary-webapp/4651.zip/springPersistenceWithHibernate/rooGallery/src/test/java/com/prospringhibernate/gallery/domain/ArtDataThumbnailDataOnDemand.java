package com.prospringhibernate.gallery.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import com.prospringhibernate.gallery.domain.ArtDataThumbnail;

@RooDataOnDemand(entity = ArtDataThumbnail.class)
public class ArtDataThumbnailDataOnDemand {
}
