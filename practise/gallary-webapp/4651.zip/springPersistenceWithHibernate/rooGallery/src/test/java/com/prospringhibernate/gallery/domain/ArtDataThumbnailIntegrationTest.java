package com.prospringhibernate.gallery.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import com.prospringhibernate.gallery.domain.ArtDataThumbnail;
import org.junit.Test;

@RooIntegrationTest(entity = ArtDataThumbnail.class)
public class ArtDataThumbnailIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
