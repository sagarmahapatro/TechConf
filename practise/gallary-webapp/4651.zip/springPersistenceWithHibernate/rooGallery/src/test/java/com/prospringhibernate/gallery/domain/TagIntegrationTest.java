package com.prospringhibernate.gallery.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import com.prospringhibernate.gallery.domain.Tag;
import org.junit.Test;

@RooIntegrationTest(entity = Tag.class)
public class TagIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
