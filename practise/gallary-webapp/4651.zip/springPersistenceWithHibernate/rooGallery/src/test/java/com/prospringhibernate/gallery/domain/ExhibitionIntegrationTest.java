package com.prospringhibernate.gallery.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import com.prospringhibernate.gallery.domain.Exhibition;
import org.junit.Test;

@RooIntegrationTest(entity = Exhibition.class)
public class ExhibitionIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
