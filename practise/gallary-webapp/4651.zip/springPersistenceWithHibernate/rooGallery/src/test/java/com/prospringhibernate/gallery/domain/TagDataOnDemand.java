package com.prospringhibernate.gallery.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import com.prospringhibernate.gallery.domain.Tag;

@RooDataOnDemand(entity = Tag.class)
public class TagDataOnDemand {
}
