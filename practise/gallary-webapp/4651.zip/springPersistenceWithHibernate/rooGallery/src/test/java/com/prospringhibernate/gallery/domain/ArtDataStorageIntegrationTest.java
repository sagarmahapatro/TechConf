package com.prospringhibernate.gallery.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import com.prospringhibernate.gallery.domain.ArtDataStorage;
import org.junit.Test;

@RooIntegrationTest(entity = ArtDataStorage.class)
public class ArtDataStorageIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
