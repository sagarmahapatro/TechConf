package com.prospringhibernate.gallery.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import com.prospringhibernate.gallery.domain.ArtData;

@RooDataOnDemand(entity = ArtData.class)
public class ArtDataDataOnDemand {
}
