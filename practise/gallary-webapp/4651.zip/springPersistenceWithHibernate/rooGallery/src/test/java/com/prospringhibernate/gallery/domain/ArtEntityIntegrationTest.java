package com.prospringhibernate.gallery.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import com.prospringhibernate.gallery.domain.ArtEntity;
import org.junit.Test;

@RooIntegrationTest(entity = ArtEntity.class)
public class ArtEntityIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
