package com.prospringhibernate.gallery.domain;

import org.springframework.roo.addon.dod.RooDataOnDemand;
import com.prospringhibernate.gallery.domain.Exhibition;

@RooDataOnDemand(entity = Exhibition.class)
public class ExhibitionDataOnDemand {
}
