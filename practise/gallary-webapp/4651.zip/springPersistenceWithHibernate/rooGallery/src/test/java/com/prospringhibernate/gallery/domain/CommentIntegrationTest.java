package com.prospringhibernate.gallery.domain;

import org.springframework.roo.addon.test.RooIntegrationTest;
import com.prospringhibernate.gallery.domain.Comment;
import org.junit.Test;

@RooIntegrationTest(entity = Comment.class)
public class CommentIntegrationTest {

    @Test
    public void testMarkerMethod() {
    }
}
