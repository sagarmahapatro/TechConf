class ExhibitionControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
