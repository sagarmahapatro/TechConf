class ArtData_ThumbnailTests extends GroovyTestCase {

    void testSomething() {

    }
}
