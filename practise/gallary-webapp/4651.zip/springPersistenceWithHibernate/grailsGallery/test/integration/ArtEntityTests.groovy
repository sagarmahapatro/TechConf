class ArtEntityTests extends GroovyTestCase {

    void testSomething() {

    }
}
