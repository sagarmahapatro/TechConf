class BioControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
