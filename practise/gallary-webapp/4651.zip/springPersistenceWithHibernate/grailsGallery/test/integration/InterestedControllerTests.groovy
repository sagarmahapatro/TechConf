class InterestedControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
