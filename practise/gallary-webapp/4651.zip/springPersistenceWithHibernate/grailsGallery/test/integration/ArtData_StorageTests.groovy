class ArtData_StorageTests extends GroovyTestCase {

    void testSomething() {

    }
}
