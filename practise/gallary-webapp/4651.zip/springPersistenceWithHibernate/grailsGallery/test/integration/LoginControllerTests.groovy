class LoginControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
