class ArtDataTests extends GroovyTestCase {

    void testSomething() {

    }
}
