class ArtEntityControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
