class ExhibitionTests extends GroovyTestCase {

    void testSomething() {

    }
}
