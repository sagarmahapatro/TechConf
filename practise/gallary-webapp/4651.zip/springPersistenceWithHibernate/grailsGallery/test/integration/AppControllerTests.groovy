class AppControllerTests extends GroovyTestCase {

    void testSomething() {

    }
}
