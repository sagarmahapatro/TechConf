class CommentTests extends GroovyTestCase {

    void testSomething() {

    }
}
