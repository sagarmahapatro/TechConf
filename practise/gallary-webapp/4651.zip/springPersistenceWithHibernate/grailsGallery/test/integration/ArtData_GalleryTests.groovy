class ArtData_GalleryTests extends GroovyTestCase {

    void testSomething() {

    }
}
