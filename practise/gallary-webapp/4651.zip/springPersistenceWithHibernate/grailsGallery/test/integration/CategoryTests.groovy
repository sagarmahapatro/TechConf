class CategoryTests extends GroovyTestCase {

    void testSomething() {

    }
}
