@artifact.package@class @artifact.name@ {

    def index = { }
}
