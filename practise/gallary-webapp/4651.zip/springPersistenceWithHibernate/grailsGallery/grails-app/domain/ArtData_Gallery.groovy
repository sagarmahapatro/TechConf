class ArtData_Gallery extends ArtData {

     public String toString() {
        return "Gallery: ${origName}"
    }

}
