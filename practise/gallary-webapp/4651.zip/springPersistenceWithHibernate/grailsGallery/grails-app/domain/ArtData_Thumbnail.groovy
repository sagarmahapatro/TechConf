class ArtData_Thumbnail extends ArtData {

    public String toString() {
        return "Thumbnail: ${origName}"
    }

}
