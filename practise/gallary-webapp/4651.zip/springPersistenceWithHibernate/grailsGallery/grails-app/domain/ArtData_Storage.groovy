class ArtData_Storage extends ArtData {

      public String toString() {
        return "Storage: ${origName}"
    }

}
