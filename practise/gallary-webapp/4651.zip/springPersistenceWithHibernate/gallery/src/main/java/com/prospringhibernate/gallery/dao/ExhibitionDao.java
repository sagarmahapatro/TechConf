package com.prospringhibernate.gallery.dao;

import com.prospringhibernate.gallery.domain.Exhibition;

public interface ExhibitionDao extends GenericDao<Exhibition> {
}
