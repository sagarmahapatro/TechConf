package com.prospringhibernate.gallery.util;

public interface ViewLookup {

    public static final String VIEW_CATEGORIES = "VIEW_CATEGORIES";

}
