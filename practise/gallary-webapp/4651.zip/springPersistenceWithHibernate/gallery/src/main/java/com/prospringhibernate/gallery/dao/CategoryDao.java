package com.prospringhibernate.gallery.dao;

import com.prospringhibernate.gallery.domain.Category;

public interface CategoryDao extends GenericDao<Category> {
}
