package com.prospringhibernate.gallery.domain;

import java.io.Serializable;

public interface DomainObject extends Serializable {

}
