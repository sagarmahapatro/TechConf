package com.prospringhibernate.gallery.test;

import org.junit.Test;
import org.junit.Assert;

public class TrivialJUnitTest {

    @Test
    public void testSimpleStuff() {
        String name = "ProSpringHibernate";
        Assert.assertEquals("ProSpringHibernate", name);
    }

}
